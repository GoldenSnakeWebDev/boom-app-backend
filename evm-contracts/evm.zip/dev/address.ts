export const Marketplace = "0x8481177d01e9e433c65fefd6140e54a3e6e1b634";

export const NFT_BOOM_TOKEN = "0x61ceeb2f2a5915e997d0969c1d790af1a938ffd6";
export const BOOM_ERC20_TOKEN = "0xabb7be22238004cec42f7deec6a88b9c0b6f630f";
